<template>
  <div id="app">
    <div id="header">
        <img src="@/assets/surfhouselogo.png">
        
    </div>
    <router-view />
    <div class="sidenav"><h2>Menu</h2>
        <router-link to="/about">About</router-link>
        <router-link to="/about2">Apparel</router-link>
        <router-link to="/">Surf apparel</router-link>
        <a href="#kitesurf">Kitesurf</a>
        <button class="dropdown-btn">Windsurf
          <i class="fa fa-caret-down"></i>
        </button>
      <div class="dropdown-container">
        <a href="#">Kites</a>
        <a href="#">KiteBoards</a>
        <button class="dropdown-btn">Bags
            <i class="fa fa-caret-down"></i>
          </button>
          <div class="dropdown-container">
              <a href="#">Magic kit</a>
              <a href="#">Pro limit s0214</a>     
            </div>
        <a href="#">Equipment</a>
      </div>
        <a href="#accessories">Accessories</a>
        <a href="#sale">Sale</a>
        <a href="#brands">Brands</a>
        <a href="#blog">Blog</a>
        <a href="#gadgets">Gadgets</a>
        <a href="#Contact">Contact</a>
      </div>

<h2>Tag Widget</h2>
  <div class="tag-widget">
    <div class="tag">Kitesurf</div>
    <div class="tag">Theme</div>
    <div class="tag">Men</div>
    <div class="tag">Women</div>
    <div class="tag">Equipment</div>
    <div class="tag">Best</div>
    <div class="tag">Accessories</div>
    <div class="tag">Men</div>
    <div class="tag">Apparel</div>
    <div class="tag">Super</div>
    <div class="tag">Duper</div>
    <div class="tag">Theme</div>
    <div class="tag">Responsive</div>
    <div class="tag">Men</div>
    <div class="tag">Women</div>
    <div class="tag">Equipment</div>
</div>


       <div class="over-footer">
            <div class="category">
                <h1 class="over-footer__font">Category</h1>
                <li><a href="#">Home</a></li>
                <li><a href="#">About us</a></li>
                <li><a href="#">Eshop</a></li>
                <li><a href="#">Features</a></li>
                <li><a href="#">New collections</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Contract</a></li>
            </div>
            <div class="our-account">
                <h1 class="over-footer__font">Our account</h1>
                <li><a href="#">Your account</a></li>
                <li><a href="#">Personal information</a></li>
                <li><a href="#">Addresses</a></li>
                <li><a href="#">Discount</a></li>
                <li><a href="#">Orders history</a></li>
                <li><a href="#">Addresses</a></li>
                <li><a href="#">Search terms</a></li>
            </div>
            <div class="our-support">
                <h1 class="over-footer__font">Our support</h1>
                <li><a href="#">Site map</a></li>
                <li><a href="#">Search terms</a></li>
                <li><a href="#">Advanced search</a></li>
                <li><a href="#">Mobile</a></li>
                <li><a href="#">Contact us</a></li>
                <li><a href="#">Mobile</a></li>
                <li><a href="#">Addresses</a></li>
            </div>
            <div class="newsletter">
                <h1 class="over-footer__font">Newsletter</h1>
                <p>Join thousands of other people subscribe to our news</p>
                <p>Insert email</p>
                <form>
                    <input type="text" text="YOUR EMAIL">
                </form>
                <p>Payment possibilities</p>
                <img src="dist\img\paypal.JPEG">
                <img src="dist\img\paypal.JPEG">
                <img src="dist\img\paypal.JPEG">
                <img src="dist\img\paypal.JPEG">
                <img src="dist\img\paypal.JPEG">
            </div>
            <div class="about-us">
                <h1 class="over-footer__font">Contact details</h1>
                <li><a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat</a></li>
                <li><a href="#">Phone: 1-999-342-9876</a></li>
                <li><a href="#">Email: info@surfhouse.com</a></li>
            </div>
        </div>
  </div>

</template>

<style>

#header {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: left;
  color: #2c3e50;
  background: #26d2fc;
}
#header {
  padding: 30px;
}

#header a {
  font-weight: bold;
  color: #2c3e50;
}

#header a.router-link-exact-active {
  color: #42b983;
}

.tag-widget {
    background: #ffffff;
    height: 5%;
    width: 10%;
    position:relative;
    z-index: 1;
    top: 0;
    left: 0;
    background-color:none ;
    overflow-x: hidden;
    margin-top: 5%;
    display: grid;
    grid-gap: 5px;
    grid-template-columns: repeat(12, 1fr);
    grid-template-rows: repeat(auto, 1fr);
    
}

.tag-widget .tag {
background: #e9e9e9;
font-size: 10px;
}

.over-footer {
    background-color: #333333;
    display: grid;
    grid-gap: 5px;
    grid-template-columns: repeat(12, 1fr);
    grid-template-rows: repeat(auto, 1fr);
    
}
</style>
