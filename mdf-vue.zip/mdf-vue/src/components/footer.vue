<template>
    <div class="over-footer">
            <div class="category">
                <h1 class="over-footer__font">Category</h1>
                <li><a href="#">Home</a></li>
                <li><a href="#">About us</a></li>
                <li><a href="#">Eshop</a></li>
                <li><a href="#">Features</a></li>
                <li><a href="#">New collections</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Contract</a></li>
            </div>
            <div class="our-account">
                <h1 class="over-footer__font">Our account</h1>
                <li><a href="#">Your account</a></li>
                <li><a href="#">Personal information</a></li>
                <li><a href="#">Addresses</a></li>
                <li><a href="#">Discount</a></li>
                <li><a href="#">Orders history</a></li>
                <li><a href="#">Addresses</a></li>
                <li><a href="#">Search terms</a></li>
            </div>
            <div class="our-support">
                <h1 class="over-footer__font">Our support</h1>
                <li><a href="#">Site map</a></li>
                <li><a href="#">Search terms</a></li>
                <li><a href="#">Advanced search</a></li>
                <li><a href="#">Mobile</a></li>
                <li><a href="#">Contact us</a></li>
                <li><a href="#">Mobile</a></li>
                <li><a href="#">Addresses</a></li>
            </div>
            <div class="newsletter">
                <h1 class="over-footer__font">Newsletter</h1>
                <p>Join thousands of other people subscribe to our news</p>
                <p>Insert email</p>
                <form>
                    <input type="text" text="YOUR EMAIL">
                </form>
                <p>Payment possibilities</p>
                <img src="dist\img\paypal.JPEG">
                <img src="dist\img\paypal.JPEG">
                <img src="dist\img\paypal.JPEG">
                <img src="dist\img\paypal.JPEG">
                <img src="dist\img\paypal.JPEG">
            </div>
            <div class="about-us">
                <h1 class="over-footer__font">Contact details</h1>
                <li><a href="#">Lorem ipsum</a></li>
                <li><a href="#">Phone: 1-999-342-9876</a></li>
                <li><a href="#">Email: info@surfhouse.com</a></li>
            </div>
        </div>
        
</template>

<script>
export default {
  name: "footer",
  props: {
    msg: String
  }
}
</script>

<style>
.over-footer {
    background-color: #333333;
    display: grid;
    grid-gap: 5px;
    grid-template-columns: repeat(12, 1fr);
    grid-template-rows: repeat(auto, 1fr);
}
</style>