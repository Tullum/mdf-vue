<template>
   
   <div class="sidenav"><h2>Menu</h2>
        <a href="@/views/About.vue">About</a>
        <a href="@/views/Contact.vue">Apparel</a>
        <a href="@/views/Home.vue">Surf apparel</a>
        <a href="#kitesurf">Kitesurf</a>
        <button class="dropdown-btn">Windsurf
          <i class="fa fa-caret-down"></i>
        </button>
      <div class="dropdown-container">
        <a href="#">Kites</a>
        <a href="#">KiteBoards</a>
        <button class="dropdown-btn">Bags
            <i class="fa fa-caret-down"></i>
          </button>
          <div class="dropdown-container">
              <a href="#">Magic kit</a>
              <a href="#">Pro limit s0214</a>     
            </div>
        <a href="#">Equipment</a>
      </div>
        <a href="#accessories">Accessories</a>
        <a href="#sale">Sale</a>
        <a href="#brands">Brands</a>
        <a href="#blog">Blog</a>
        <a href="#gadgets">Gadgets</a>
        <a href="#Contact">Contact</a>
      </div>
</template>

<script>
export default {
  name: "navbar",
  props: {
    msg: String
  }
};

//* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>

<style>
/* Fixed sidenav, full height */
.sidenav {
  height: 50%;
  width: 15%;
  position:relative;
  z-index: 1;
  top: 0;
  left: 0;
  background-color:none ;
  overflow-x: hidden;
  margin-top: 5%;
}

.sidenav h2 {
    background: #333333;
    padding: 6%;
    font-family: "Avenir", Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    font-size: 25px;
    color: #ffffff;
    
}

/* Style the sidenav links and the dropdown button */
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #333333;
  display: block;
  border: none;
  background: #26d2fc ;
  width:100%;
  text-align: left;
  cursor: pointer;
  outline: none;
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* On mouse-over */
.sidenav a:hover, .dropdown-btn:hover {
  color: #ffffff;
  background-color: #333333;
}


/* Add an active class to the active dropdown button */
.active {
  background-color: #333333;
  color: #333333;
}

/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  background-color: #75e3fe;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 8px;
}
</style>
