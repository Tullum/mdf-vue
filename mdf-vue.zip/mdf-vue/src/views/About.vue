<template>
  <div class="about">
    <div class="image-product">
    <img src=" @/assets/rrd-freestyle-wave-ltd-v3-100-2.png">
    </div>
    <div class="product-information">
    <h1>Peeky Cropped</h1>
    <h2>€.578.50</h2>
    <h3>Quick overview</h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat</p>
    <h3>Size</h3>
    <button>25</button>
    <button>26</button>
    <button>27</button>
    <button>28</button>
    <button>29</button>
    <button>30</button>
    <button>31</button>
    <button>32</button>
    <button>33</button>
    <h3>Lenght</h3>
    <button>32</button>
    <button>34</button>
    <h3>Quantity</h3>
    <input type="text" value="1">
    <button>ADD TO CART</button>
    <button>+ Add to Wishlist</button>
    <button>+ Add to compare</button>
    <button>+ Email to a friend</button>
    </div>

    <div class="product-description">
      <div class="button-section"> 
        <button>Product description</button>
        <button>Additional information</button>
        <button>Product tags</button>
      </div>
      <p>There are many variations of passages of lorem ipsum available, but the majority have sufferet alteration in some form, by injected humour, or randomized words <br>
          Which don’t look even slightly believable. If you are going to use a passage of lorum ipsum, you need to be sure there isn’t anything embarrassing hidden in the<br>
          Middle of text.
      </p>
      <p>
        There are many variations of passages of lorem ipsum available, but the majority have sufferet alteration in some form, by injected humour, or randomized words <br>
        Which don’t look even slightly believable. If you are going to use a passage of lorum ipsum, you need to be sure there isn’t anything embarrassing hidden in the<br>
        Middle of text.
      </p>
      <p>
        -	6.1 oz. 100 % preshrunk heavy weight cotton<br>
        -	Shoulder-to-shoulder taping<br>
        -	Double-needle sleeves and bottom hem<br>
        It uses a dictionary of over 200 latin words, combined with a handful of a model sentence structures, to generate lorem ipsum which look reasonable.
      </p>

    </div>


  </div>
</template>
