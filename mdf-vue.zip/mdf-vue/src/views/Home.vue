<template>
  <div class="home">
    
    <div class="content">
        <div class="cover-img">
          <img src="src/assets/slider01copy.png">
      </div>
    </div>
    <div class="img-container">
        <div class="small"><img src="@/assets/ImageSurfboard.png" width="100%"></div>
        <div class="small"><img src="@/assets/ImageSurfboard.png" width="100%"></div>
        <div class="small"><img src="@/assets/ImageSurfboard.png" width="100%"></div>
        <div class="small"><img src="@/assets/ImageSurfboard.png" width="100%"></div>
        <div class="small"><img src="@/assets/ImageSurfboard.png" width="100%"></div>
        <div class="small"><img src="@/assets/ImageSurfboard.png" width="100%"></div>
    </div>   
  </div>
</template>

<script>
// @ is an alias to /src

import navbar from "@/components/navbar.vue";
import footer from "@/components/footer.vue";
import contact from "@/views/Contact.vue";

export default {
  name: "home",
  components: {
    navbar,
    contact,
    footer
  }
};
</script>

<style>
.img-container{
    display: grid;
    grid-gap: 10px;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    grid-auto-flow: dense;
}

.small {
grid-column: repeat(3, 1fr);
grid-row: repeat(2, 1fr);

}
</style>
