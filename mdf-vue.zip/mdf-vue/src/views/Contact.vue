<template>
<div id="app"> 
<div class="contact">
    <h1>CONTACT US</h1>
    <H2>If you have any questions about your order or need any general information our customer service team will be happy to assist you</H2>

    <form>
        <p>FULL NAME*</p>
        <input type="text" text="e.g. Robert Smith">
        <p>EMAIL*</p>
        <input type="text" text="e.g. name@nome.com">
        <p>COMPANY</p>
        <input type="text" text="e.g. Your Company (optional)">
        <p>SUBJECT*</p>
        <input type="text" text="e.g. Info">
        <p>MESSAGE</p>
        <input type="text">
        <input type="button" text="Send">
    </form>
</div>
</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
